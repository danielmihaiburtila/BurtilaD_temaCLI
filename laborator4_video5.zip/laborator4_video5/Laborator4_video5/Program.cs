﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laborator4_video5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Window3D wd = new Window3D();
            wd.Run(30.0, 0.0);
        }
    }
}
